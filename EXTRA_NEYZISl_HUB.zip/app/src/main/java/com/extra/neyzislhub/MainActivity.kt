package com.extra.neyzislhub

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Forum
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {
    private var tick by mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { HubTheme { HubApp(tick) } }
    }

    override fun onResume() {
        super.onResume()
        tick++
    }
}

enum class Stage { KEY, LOADING, HUB }

@Composable
fun HubApp(tick: Int) {
    val ctx = LocalContext.current
    var stage by remember { mutableStateOf(if (Prefs.keyOk(ctx)) Stage.HUB else Stage.KEY) }
    Box(
        Modifier
            .fillMaxSize()
            .background(HubBlack)
            .systemBarsPadding()
            .imePadding()
    ) {
        when (stage) {
            Stage.KEY -> KeyScreen(onOk = { Prefs.setKeyOk(ctx, true); stage = Stage.LOADING })
            Stage.LOADING -> LoadingScreen(onDone = { stage = Stage.HUB })
            Stage.HUB -> HubScreen(tick, onLogout = { Prefs.setKeyOk(ctx, false); stage = Stage.KEY })
        }
    }
}

@Composable
fun Logo(size: Int = 84) {
    Box(
        Modifier
            .size(size.dp)
            .clip(RoundedCornerShape((size / 4).dp))
            .background(HubYellow),
        contentAlignment = Alignment.Center
    ) {
        Text("⚡", fontSize = (size / 2).sp, color = Color.Black)
    }
}

@Composable
fun hubFieldColors() = OutlinedTextFieldDefaults.colors(
    focusedBorderColor = HubYellow,
    unfocusedBorderColor = HubCard2,
    cursorColor = HubYellow,
    focusedLabelColor = HubYellow,
    unfocusedLabelColor = HubGrey,
    focusedTextColor = HubWhite,
    unfocusedTextColor = HubWhite,
    errorBorderColor = HubRed,
)

@Composable
fun KeyScreen(onOk: () -> Unit) {
    var key by remember { mutableStateOf("") }
    var error by remember { mutableStateOf(false) }
    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(28.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Logo()
        Spacer(Modifier.height(22.dp))
        Text(
            "EXTRA + NEYZISl • HUB",
            color = HubYellow, fontSize = 26.sp, fontWeight = FontWeight.Black, textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(6.dp))
        Text("Введи ключ доступа, чтобы продолжить", color = HubGrey, textAlign = TextAlign.Center)
        Spacer(Modifier.height(28.dp))
        OutlinedTextField(
            value = key,
            onValueChange = { key = it; error = false },
            singleLine = true,
            label = { Text("Ключ") },
            isError = error,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Ascii),
            shape = RoundedCornerShape(14.dp),
            colors = hubFieldColors(),
            modifier = Modifier.fillMaxWidth()
        )
        if (error) {
            Spacer(Modifier.height(6.dp))
            Text("Неверный ключ", color = HubRed, fontSize = 13.sp)
        }
        Spacer(Modifier.height(18.dp))
        Button(
            onClick = { if (key.trim().equals(Prefs.SECRET_KEY, ignoreCase = true)) onOk() else error = true },
            colors = ButtonDefaults.buttonColors(containerColor = HubYellow, contentColor = Color.Black),
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(54.dp)
        ) { Text("ЗАГРУЗИТЬ", fontWeight = FontWeight.Black, fontSize = 16.sp) }
    }
}

@Composable
fun LoadingScreen(onDone: () -> Unit) {
    val steps = listOf("Подключение модулей…", "Подготовка базы…", "Настройка интерфейса…", "Готово")
    var p by remember { mutableFloatStateOf(0f) }
    var step by remember { mutableIntStateOf(0) }
    LaunchedEffect(Unit) {
        for (i in 1..100) {
            p = i / 100f
            step = (i * steps.size / 101).coerceAtMost(steps.lastIndex)
            delay(28)
        }
        delay(250)
        onDone()
    }
    Column(
        Modifier
            .fillMaxSize()
            .padding(36.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Logo(96)
        Spacer(Modifier.height(28.dp))
        Text("Загрузка…", color = HubWhite, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(16.dp))
        LinearProgressIndicator(
            progress = { p },
            color = HubYellow,
            trackColor = HubCard2,
            modifier = Modifier
                .fillMaxWidth()
                .height(8.dp)
                .clip(RoundedCornerShape(8.dp))
        )
        Spacer(Modifier.height(12.dp))
        Text(steps[step], color = HubGrey, fontSize = 14.sp)
    }
}

@Composable
fun PermCard(title: String, desc: String, granted: Boolean, required: Boolean, btn: String, onClick: () -> Unit) {
    Surface(
        color = HubCard,
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, if (granted) HubCard2 else HubYellow.copy(alpha = .6f)),
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp)
    ) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(title, color = HubWhite, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                Text(
                    if (granted) "✓ выдано" else if (required) "обязательно" else "по желанию",
                    color = if (granted) HubYellow else HubGrey, fontSize = 12.sp
                )
            }
            Spacer(Modifier.height(4.dp))
            Text(desc, color = HubGrey, fontSize = 13.sp)
            if (!granted) {
                Spacer(Modifier.height(10.dp))
                Button(
                    onClick = onClick,
                    colors = ButtonDefaults.buttonColors(containerColor = HubYellow, contentColor = Color.Black),
                    shape = RoundedCornerShape(12.dp)
                ) { Text(btn, fontWeight = FontWeight.Bold) }
            }
        }
    }
}

@Composable
fun PermissionScreen(overlay: Boolean, postNotif: Boolean, askPost: () -> Unit) {
    val ctx = LocalContext.current
    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(20.dp)
    ) {
        Spacer(Modifier.height(10.dp))
        Logo(60)
        Spacer(Modifier.height(16.dp))
        Text("Нужны разрешения", color = HubWhite, fontSize = 26.sp, fontWeight = FontWeight.Black)
        Spacer(Modifier.height(6.dp))
        Text(
            "Без доступа к уведомлениям приложению нечего показывать: чаты строятся из уведомлений, " +
                "которые приходят на этот телефон.",
            color = HubGrey
        )
        Spacer(Modifier.height(14.dp))
        PermCard(
            "Доступ к уведомлениям",
            "Приложение читает уведомления выбранных мессенджеров и ловит «сообщение удалено».",
            false, true, "Дать доступ"
        ) { ctx.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }
        PermCard(
            "Поверх других окон",
            "Нужно для плавающего оверлей-меню.",
            overlay, false, "Разрешить"
        ) {
            ctx.startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${ctx.packageName}"))
            )
        }
        PermCard(
            "Свои уведомления",
            "Чтобы приложение сообщало «в чате X удалили сообщение».",
            postNotif, false, "Разрешить", askPost
        )
        Spacer(Modifier.height(10.dp))
        Text(
            "Если переключатель доступа к уведомлениям серый (Android 13+): Настройки → Приложения → " +
                "EXTRA + NEYZISl • HUB → ⋮ (меню) → «Разрешить ограниченные настройки», потом снова дай доступ.",
            color = HubGrey, fontSize = 12.sp
        )
    }
}

@Composable
fun HubScreen(tick: Int, onLogout: () -> Unit) {
    val ctx = LocalContext.current
    val listener = remember(tick) {
        NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName)
    }
    val overlay = remember(tick) { Settings.canDrawOverlays(ctx) }
    val postNotif = remember(tick) {
        Build.VERSION.SDK_INT < 33 ||
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) ==
            PackageManager.PERMISSION_GRANTED
    }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    val askPost = { launcher.launch(Manifest.permission.POST_NOTIFICATIONS) }

    if (!listener) {
        PermissionScreen(overlay, postNotif, askPost)
    } else {
        MainTabs(tick, overlay, postNotif, askPost, onLogout)
    }
}

@Composable
fun MainTabs(tick: Int, overlay: Boolean, postNotif: Boolean, askPost: () -> Unit, onLogout: () -> Unit) {
    var tab by remember { mutableIntStateOf(0) }
    var open by remember { mutableStateOf<Pair<String, String>?>(null) }
    BackHandler(open != null) { open = null }

    Scaffold(
        containerColor = HubBlack,
        bottomBar = {
            if (open == null) {
                NavigationBar(containerColor = HubCard) {
                    val colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color.Black,
                        selectedTextColor = HubYellow,
                        indicatorColor = HubYellow,
                        unselectedIconColor = HubGrey,
                        unselectedTextColor = HubGrey,
                    )
                    NavigationBarItem(tab == 0, { tab = 0 }, { Icon(Icons.Filled.Forum, null) }, label = { Text("Чаты") }, colors = colors)
                    NavigationBarItem(tab == 1, { tab = 1 }, { Icon(Icons.Filled.DeleteSweep, null) }, label = { Text("Удалённые") }, colors = colors)
                    NavigationBarItem(tab == 2, { tab = 2 }, { Icon(Icons.Filled.Tune, null) }, label = { Text("Функции") }, colors = colors)
                }
            }
        }
    ) { pad ->
        Box(
            Modifier
                .padding(pad)
                .fillMaxSize()
        ) {
            val o = open
            if (o != null) {
                ChatScreen(o.first, o.second) { open = null }
            } else when (tab) {
                0 -> ChatsScreen { pkg, chat -> open = pkg to chat }
                1 -> DeletedScreen { pkg, chat -> open = pkg to chat }
                else -> ToolsScreen(tick, overlay, postNotif, askPost, onLogout)
            }
        }
    }
}
