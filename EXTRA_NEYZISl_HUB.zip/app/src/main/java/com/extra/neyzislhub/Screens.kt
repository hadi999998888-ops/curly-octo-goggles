package com.extra.neyzislhub

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.text.format.DateUtils
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

fun fmtTime(t: Long): String {
    val d = Date(t)
    return if (DateUtils.isToday(t)) SimpleDateFormat("HH:mm", Locale.getDefault()).format(d)
    else SimpleDateFormat("dd.MM HH:mm", Locale.getDefault()).format(d)
}

/** Читает данные из базы в фоне и перечитывает их при каждом изменении базы или смене key. */
@Composable
fun <T> storeState(init: T, key: Any?, load: (Store) -> T): T {
    val ctx = LocalContext.current.applicationContext
    val ver by Store.changes.collectAsState()
    var v by remember { mutableStateOf(init) }
    LaunchedEffect(ver, key) { v = withContext(Dispatchers.IO) { load(Store.get(ctx)) } }
    return v
}

@Composable
fun ScreenTitle(text: String, sub: String? = null) {
    Column(Modifier.padding(horizontal = 20.dp, vertical = 14.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier
                    .width(6.dp)
                    .height(24.dp)
                    .clip(RoundedCornerShape(3.dp))
                    .background(HubYellow)
            )
            Spacer(Modifier.width(10.dp))
            Text(text, color = HubWhite, fontSize = 24.sp, fontWeight = FontWeight.Black)
        }
        if (sub != null) Text(sub, color = HubGrey, fontSize = 13.sp, modifier = Modifier.padding(start = 16.dp, top = 2.dp))
    }
}

@Composable
fun Avatar(name: String, size: Dp = 46.dp) {
    Box(
        Modifier
            .size(size)
            .clip(CircleShape)
            .background(HubYellow),
        contentAlignment = Alignment.Center
    ) {
        Text(
            name.trim().take(1).uppercase().ifEmpty { "?" },
            color = Color.Black, fontWeight = FontWeight.Black, fontSize = 20.sp
        )
    }
}

@Composable
fun EmptyState(text: String) {
    Box(Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("⚡", fontSize = 40.sp)
            Spacer(Modifier.height(10.dp))
            Text(text, color = HubGrey, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
        }
    }
}

// ───────────────────────── Чаты ─────────────────────────

@Composable
fun ChatsScreen(onOpen: (String, String) -> Unit) {
    var q by remember { mutableStateOf("") }
    val chats = storeState(emptyList<ChatItem>(), q) { it.chats(q) }
    Column(Modifier.fillMaxSize()) {
        ScreenTitle("Чаты", "Сообщения, пойманные из уведомлений")
        OutlinedTextField(
            value = q, onValueChange = { q = it },
            singleLine = true,
            placeholder = { Text("Поиск по чатам и тексту", color = HubGrey) },
            leadingIcon = { Icon(Icons.Filled.Search, null, tint = HubGrey) },
            shape = RoundedCornerShape(14.dp),
            colors = hubFieldColors(),
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
        )
        Spacer(Modifier.height(6.dp))
        if (chats.isEmpty()) {
            EmptyState(
                if (q.isBlank()) "Пока пусто.\nКак только в выбранных мессенджерах придёт сообщение, чат появится здесь."
                else "Ничего не найдено"
            )
        } else {
            LazyColumn(Modifier.fillMaxSize()) {
                items(chats, key = { it.pkg + "|" + it.chat }) { c ->
                    ChatRow(c) { onOpen(c.pkg, c.chat) }
                }
            }
        }
    }
}

@Composable
fun ChatRow(c: ChatItem, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 20.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Avatar(c.chat)
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(c.chat, color = HubWhite, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(c.last, color = HubGrey, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(c.app, color = HubYellow.copy(alpha = .7f), fontSize = 11.sp)
        }
        Spacer(Modifier.width(8.dp))
        Column(horizontalAlignment = Alignment.End) {
            Text(fmtTime(c.time), color = HubGrey, fontSize = 12.sp)
            if (c.deletedCount > 0) {
                Spacer(Modifier.height(4.dp))
                Box(
                    Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .background(HubYellow)
                        .padding(horizontal = 8.dp, vertical = 2.dp)
                ) {
                    Text("🗑 ${c.deletedCount}", color = Color.Black, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

// ───────────────────────── Переписка ─────────────────────────

@Composable
fun ChatScreen(pkg: String, chat: String, onBack: () -> Unit) {
    val msgs = storeState(emptyList<Msg>(), pkg + "|" + chat) { it.messages(pkg, chat) }
    val state = rememberLazyListState()
    LaunchedEffect(msgs.size) { if (msgs.isNotEmpty()) state.scrollToItem(msgs.lastIndex) }
    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier
                .fillMaxWidth()
                .background(HubCard)
                .padding(horizontal = 8.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null, tint = HubYellow) }
            Avatar(chat, 38.dp)
            Spacer(Modifier.width(10.dp))
            Column {
                Text(chat, color = HubWhite, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(appName(pkg), color = HubGrey, fontSize = 12.sp)
            }
        }
        LazyColumn(
            state = state,
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            item { Spacer(Modifier.height(6.dp)) }
            items(msgs, key = { it.id }) { m -> Bubble(m, showSender = m.sender != chat) }
            item { Spacer(Modifier.height(10.dp)) }
        }
    }
}

@Composable
fun Bubble(m: Msg, showSender: Boolean) {
    Surface(
        color = if (m.deleted) HubCard2 else HubCard,
        shape = RoundedCornerShape(topStart = 4.dp, topEnd = 16.dp, bottomStart = 16.dp, bottomEnd = 16.dp),
        border = if (m.deleted) BorderStroke(1.dp, HubYellow) else null,
        modifier = Modifier.fillMaxWidth(0.88f)
    ) {
        Column(Modifier.padding(12.dp)) {
            if (showSender) Text(m.sender, color = HubYellow, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Text(m.text, color = HubWhite, fontSize = 15.sp)
            Spacer(Modifier.height(4.dp))
            Row {
                Text(fmtTime(m.time), color = HubGrey, fontSize = 11.sp)
                if (m.deleted) {
                    Spacer(Modifier.width(8.dp))
                    Text("🗑 УДАЛЕНО", color = HubYellow, fontSize = 11.sp, fontWeight = FontWeight.Black)
                }
            }
        }
    }
}

// ───────────────────────── Удалённые ─────────────────────────

@Composable
fun DeletedScreen(onOpen: (String, String) -> Unit) {
    val list = storeState(emptyList<Msg>(), null) { it.deleted() }
    Column(Modifier.fillMaxSize()) {
        ScreenTitle("Удалённые", if (list.isEmpty()) null else "Всего: ${list.size}")
        if (list.isEmpty()) {
            EmptyState("Удалённых сообщений пока нет.\nКогда собеседник удалит сообщение, которое уже пришло уведомлением, оно окажется здесь.")
        } else {
            LazyColumn(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(list, key = { it.id }) { m ->
                    Surface(
                        color = HubCard,
                        shape = RoundedCornerShape(16.dp),
                        border = BorderStroke(1.dp, HubYellow.copy(alpha = .6f)),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp)
                            .clickable { onOpen(m.pkg, m.chat) }
                    ) {
                        Column(Modifier.padding(14.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    "${m.chat} • ${appName(m.pkg)}", color = HubYellow,
                                    fontWeight = FontWeight.Bold, fontSize = 13.sp,
                                    modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis
                                )
                                Text("удалено ${fmtTime(m.deletedAt)}", color = HubGrey, fontSize = 11.sp)
                            }
                            if (m.sender != m.chat) Text(m.sender, color = HubGrey, fontSize = 12.sp)
                            Spacer(Modifier.height(4.dp))
                            Text(m.text, color = HubWhite, fontSize = 15.sp)
                        }
                    }
                }
                item { Spacer(Modifier.height(10.dp)) }
            }
        }
    }
}

// ───────────────────────── Функции ─────────────────────────

@Composable
fun SectionCard(title: String, content: @Composable () -> Unit) {
    Surface(
        color = HubCard,
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp)
    ) {
        Column(Modifier.padding(16.dp)) {
            Text(title, color = HubYellow, fontWeight = FontWeight.Black, fontSize = 14.sp)
            Spacer(Modifier.height(8.dp))
            content()
        }
    }
}

@Composable
fun SwitchRow(title: String, desc: String? = null, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, color = HubWhite)
            if (desc != null) Text(desc, color = HubGrey, fontSize = 12.sp)
        }
        Switch(
            checked = checked, onCheckedChange = onChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.Black, checkedTrackColor = HubYellow,
                uncheckedThumbColor = HubGrey, uncheckedTrackColor = HubCard2,
                uncheckedBorderColor = HubCard2,
            )
        )
    }
}

private fun writeExport(ctx: Context): File {
    val store = Store.get(ctx)
    val sb = StringBuilder("EXTRA + NEYZISl • HUB — экспорт\n\n")
    for (c in store.chats("")) {
        sb.append("=== ${c.chat} (${c.app}) ===\n")
        for (m in store.messages(c.pkg, c.chat)) {
            sb.append("[${fmtTime(m.time)}] ")
            if (m.sender != c.chat) sb.append("${m.sender}: ")
            sb.append(m.text)
            if (m.deleted) sb.append("  <УДАЛЕНО>")
            sb.append('\n')
        }
        sb.append('\n')
    }
    val dir = File(ctx.cacheDir, "exports").apply { mkdirs() }
    return File(dir, "hub_export.txt").apply { writeText(sb.toString()) }
}

@Composable
fun ToolsScreen(tick: Int, overlay: Boolean, postNotif: Boolean, askPost: () -> Unit, onLogout: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val stats = storeState(0 to 0, null) { it.stats() }

    var tracking by remember { mutableStateOf(Prefs.tracking(ctx)) }
    var overlayOn by remember(tick) { mutableStateOf(Prefs.overlayOn(ctx)) }
    var watched by remember { mutableStateOf(Prefs.watched(ctx)) }
    var confirmClear by remember { mutableStateOf(false) }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp)
    ) {
        ScreenTitle("Функции")

        SectionCard("Статистика") {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                StatBox(stats.first.toString(), "сохранено")
                StatBox(stats.second.toString(), "удалено")
            }
        }

        SectionCard("Основное") {
            SwitchRow(
                "Отслеживать удалённые", "Сохранять сообщения и ловить «сообщение удалено»",
                tracking
            ) { tracking = it; Prefs.setTracking(ctx, it) }
            SwitchRow(
                "Оверлей-меню ⚡", "Плавающая кнопка поверх приложений: удалённые, лента, быстрые переключатели",
                overlayOn
            ) { on ->
                if (on) {
                    if (!Settings.canDrawOverlays(ctx)) {
                        ctx.startActivity(
                            Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${ctx.packageName}"))
                        )
                    } else {
                        ContextCompat.startForegroundService(ctx, Intent(ctx, OverlayService::class.java))
                        overlayOn = true
                    }
                } else {
                    ctx.stopService(Intent(ctx, OverlayService::class.java))
                    overlayOn = false
                }
            }
        }

        SectionCard("За какими приложениями следить") {
            for (app in KNOWN_APPS) {
                SwitchRow(app.name, null, app.pkg in watched) { on ->
                    watched = if (on) watched + app.pkg else watched - app.pkg
                    Prefs.setWatched(ctx, watched)
                }
            }
        }

        SectionCard("Данные") {
            Button(
                onClick = {
                    scope.launch {
                        val f = withContext(Dispatchers.IO) { writeExport(ctx) }
                        val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".fp", f)
                        val send = Intent(Intent.ACTION_SEND).apply {
                            type = "text/plain"
                            putExtra(Intent.EXTRA_STREAM, uri)
                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        }
                        ctx.startActivity(
                            Intent.createChooser(send, "Экспорт переписок").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        )
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = HubYellow, contentColor = Color.Black),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) { Text("Экспорт в .txt", fontWeight = FontWeight.Bold) }
            Spacer(Modifier.height(8.dp))
            OutlinedButton(
                onClick = { confirmClear = true },
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, HubRed),
                modifier = Modifier.fillMaxWidth()
            ) { Text("Очистить всю базу", color = HubRed) }
        }

        SectionCard("Разрешения") {
            PermLine("Поверх других окон", overlay) {
                ctx.startActivity(
                    Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${ctx.packageName}"))
                )
            }
            PermLine("Свои уведомления", postNotif, askPost)
            PermLine("Доступ к уведомлениям", true) {}
        }

        SectionCard("О приложении") {
            Text(
                "Чаты строятся только из уведомлений, которые пришли на этот телефон уже после выдачи доступа. " +
                    "Историю, которая приходила раньше, а также сообщения из отключённых чатов приложение увидеть не может. " +
                    "Всё хранится локально на устройстве.",
                color = HubGrey, fontSize = 12.sp
            )
            Spacer(Modifier.height(8.dp))
            TextButton(onClick = onLogout) { Text("Выйти (сменить ключ)", color = HubYellow) }
        }
        Spacer(Modifier.height(16.dp))
    }

    if (confirmClear) {
        AlertDialog(
            onDismissRequest = { confirmClear = false },
            containerColor = HubCard,
            title = { Text("Очистить базу?", color = HubWhite) },
            text = { Text("Все сохранённые сообщения будут удалены с телефона.", color = HubGrey) },
            confirmButton = {
                TextButton(onClick = {
                    confirmClear = false
                    scope.launch(Dispatchers.IO) { Store.get(ctx).clearAll() }
                }) { Text("Очистить", color = HubRed) }
            },
            dismissButton = { TextButton(onClick = { confirmClear = false }) { Text("Отмена", color = HubYellow) } }
        )
    }
}

@Composable
fun StatBox(value: String, label: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, color = HubYellow, fontSize = 30.sp, fontWeight = FontWeight.Black)
        Text(label, color = HubGrey, fontSize = 12.sp)
    }
}

@Composable
fun PermLine(title: String, granted: Boolean, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(title, color = HubWhite, modifier = Modifier.weight(1f))
        if (granted) Text("✓", color = HubYellow, fontWeight = FontWeight.Black)
        else TextButton(onClick = onClick) { Text("Выдать", color = HubYellow) }
    }
}
