package com.extra.neyzislhub

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.text.format.DateUtils
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import androidx.core.app.ServiceCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs

private val Y = Color.parseColor("#FFD400")
private val BG = Color.parseColor("#0A0A0A")
private val CARD = Color.parseColor("#1C1C1C")
private val GREY = Color.parseColor("#9A9A9A")

private fun Context.dp(v: Int) = (v * resources.displayMetrics.density).toInt()

/** Плавающая кнопка ⚡ + выдвижное меню поверх других приложений. */
class OverlayService : Service() {

    private lateinit var wm: WindowManager
    private var bubble: TextView? = null
    private var bubbleLp: WindowManager.LayoutParams? = null
    private var panel: View? = null
    private var listBox: LinearLayout? = null
    private var tab = 0
    private val handler = Handler(Looper.getMainLooper())
    private val refresh = object : Runnable {
        override fun run() {
            fillList()
            handler.postDelayed(this, 2000)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("overlay", "Оверлей-меню", NotificationManager.IMPORTANCE_LOW)
        )
        val n = Notification.Builder(this, "overlay")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("EXTRA + NEYZISl • HUB")
            .setContentText("Оверлей-меню включено")
            .setOngoing(true)
            .build()
        ServiceCompat.startForeground(
            this, 1, n,
            if (Build.VERSION.SDK_INT >= 34) ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE else 0
        )
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return
        }
        Prefs.setOverlayOn(this, true)
        addBubble()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int) = START_STICKY

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        hidePanel()
        bubble?.let { runCatching { wm.removeView(it) } }
        bubble = null
        Prefs.setOverlayOn(this, false)
        super.onDestroy()
    }

    private fun addBubble() {
        val size = dp(56)
        val tv = TextView(this).apply {
            text = "⚡"
            textSize = 24f
            gravity = Gravity.CENTER
            setTextColor(Color.BLACK)
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Y)
                setStroke(dp(2), Color.BLACK)
            }
        }
        val lp = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(8)
            y = dp(240)
        }
        var sx = 0
        var sy = 0
        var tx = 0f
        var ty = 0f
        var moved = false
        tv.setOnTouchListener { v, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    sx = lp.x; sy = lp.y; tx = e.rawX; ty = e.rawY; moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - tx).toInt()
                    val dy = (e.rawY - ty).toInt()
                    if (abs(dx) > dp(6) || abs(dy) > dp(6)) moved = true
                    if (moved) {
                        lp.x = sx + dx
                        lp.y = sy + dy
                        wm.updateViewLayout(v, lp)
                        if (panel != null) hidePanel()
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) togglePanel()
                    true
                }
                else -> false
            }
        }
        wm.addView(tv, lp)
        bubble = tv
        bubbleLp = lp
    }

    private fun togglePanel() {
        if (panel != null) hidePanel() else showPanel()
    }

    private fun hidePanel() {
        handler.removeCallbacks(refresh)
        panel?.let { runCatching { wm.removeView(it) } }
        panel = null
        listBox = null
    }

    private fun label(text: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        this.text = text
        textSize = size
        setTextColor(color)
        if (bold) setTypeface(typeface, Typeface.BOLD)
    }

    private fun button(text: String, filled: Boolean, onClick: () -> Unit) = TextView(this).apply {
        this.text = text
        textSize = 12f
        gravity = Gravity.CENTER
        setTextColor(if (filled) Color.BLACK else Color.WHITE)
        setTypeface(typeface, Typeface.BOLD)
        setPadding(dp(10), dp(9), dp(10), dp(9))
        background = GradientDrawable().apply {
            cornerRadius = dp(10).toFloat()
            setColor(if (filled) Y else CARD)
        }
        setOnClickListener { onClick() }
    }

    private fun showPanel() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(12))
            background = GradientDrawable().apply {
                cornerRadius = dp(18).toFloat()
                setColor(BG)
                setStroke(dp(2), Y)
            }
        }
        root.addView(label("EXTRA + NEYZISl • HUB", 15f, Y, true))

        val (total, del) = Store.get(this).stats()
        root.addView(label("Сохранено: $total  •  Удалено: $del", 12f, GREY).apply { setPadding(0, dp(2), 0, dp(8)) })

        root.addView(Switch(this).apply {
            text = "Отслеживать удалённые"
            setTextColor(Color.WHITE)
            isChecked = Prefs.tracking(this@OverlayService)
            setOnCheckedChangeListener { _, on -> Prefs.setTracking(this@OverlayService, on) }
        })

        val tabs = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(10), 0, dp(8))
        }
        fun styleTabs(a: TextView, b: TextView) {
            for ((i, t) in listOf(a, b).withIndex()) {
                val sel = tab == i
                t.setTextColor(if (sel) Color.BLACK else Color.WHITE)
                (t.background as GradientDrawable).setColor(if (sel) Y else CARD)
            }
        }
        val tabDel = button("Удалённые", true) {}
        val tabLive = button("Лента", false) {}
        tabDel.setOnClickListener { tab = 0; styleTabs(tabDel, tabLive); fillList() }
        tabLive.setOnClickListener { tab = 1; styleTabs(tabDel, tabLive); fillList() }
        styleTabs(tabDel, tabLive)
        tabs.addView(tabDel, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { rightMargin = dp(6) })
        tabs.addView(tabLive, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        root.addView(tabs)

        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        listBox = box
        val scroll = ScrollView(this).apply { addView(box) }
        root.addView(scroll, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(230)))

        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(10), 0, 0)
        }
        row.addView(button("Открыть HUB", true) {
            startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            hidePanel()
        }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { rightMargin = dp(6) })
        row.addView(button("Скрыть", false) { hidePanel() },
            LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { rightMargin = dp(6) })
        row.addView(button("Выкл.", false) { stopSelf() },
            LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        root.addView(row)

        val dm = resources.displayMetrics
        val w = dp(300)
        val b = bubbleLp
        var x = (b?.x ?: 0) + dp(64)
        if (x + w > dm.widthPixels) x = (b?.x ?: 0) - w - dp(8)
        x = x.coerceAtLeast(dp(4))
        val y = (b?.y ?: 0).coerceIn(0, (dm.heightPixels - dp(430)).coerceAtLeast(0))

        val lp = WindowManager.LayoutParams(
            w, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            this.x = x
            this.y = y
        }
        wm.addView(root, lp)
        panel = root
        handler.post(refresh)
    }

    private fun fillList() {
        val box = listBox ?: return
        val store = Store.get(this)
        val data = if (tab == 0) store.deleted(8) else store.recent(8)
        box.removeAllViews()
        if (data.isEmpty()) {
            box.addView(label(
                if (tab == 0) "Удалённых пока нет" else "Сообщений пока нет", 13f, GREY
            ).apply { setPadding(0, dp(8), 0, dp(8)) })
            return
        }
        val fmt = SimpleDateFormat("HH:mm", Locale.getDefault())
        for (m in data) {
            val item = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(10), dp(8), dp(10), dp(8))
                background = GradientDrawable().apply {
                    cornerRadius = dp(10).toFloat()
                    setColor(CARD)
                    if (m.deleted) setStroke(dp(1), Y)
                }
            }
            val ts = if (DateUtils.isToday(m.time)) fmt.format(Date(m.time)) else DateUtils.formatDateTime(
                this, m.time, DateUtils.FORMAT_SHOW_DATE or DateUtils.FORMAT_SHOW_TIME
            )
            item.addView(label("${if (m.deleted) "🗑 " else ""}${m.chat} • $ts", 11f, Y, true))
            item.addView(label(m.text, 13f, Color.WHITE).apply { maxLines = 4 })
            box.addView(item, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = dp(6) })
        }
    }
}
