package com.extra.neyzislhub

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val HubBlack = Color(0xFF0A0A0A)
val HubCard = Color(0xFF171717)
val HubCard2 = Color(0xFF242424)
val HubYellow = Color(0xFFFFD400)
val HubWhite = Color(0xFFF5F5F5)
val HubGrey = Color(0xFF9A9A9A)
val HubRed = Color(0xFFFF5252)

@Composable
fun HubTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = HubYellow,
            onPrimary = Color.Black,
            secondary = HubYellow,
            background = HubBlack,
            onBackground = HubWhite,
            surface = HubCard,
            onSurface = HubWhite,
            surfaceVariant = HubCard2,
            onSurfaceVariant = HubGrey,
            outline = HubGrey,
        ),
        content = content
    )
}
