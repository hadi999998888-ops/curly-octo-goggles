package com.extra.neyzislhub

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.os.Build
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

private val DELETED_MARKERS = listOf(
    "this message was deleted", "message was deleted",
    "это сообщение удалено", "сообщение удалено", "удалил(а) это сообщение",
    "mensaje eliminado", "se eliminó este mensaje",
    "diese nachricht wurde gelöscht", "nachricht wurde gelöscht",
    "bu mesaj silindi", "mesaj silindi",
)

private val NOISE = Regex(
    "^\\d+\\s+(new\\s+)?(messages?|сообщен|нов)|checking for new messages|новые сообщения",
    RegexOption.IGNORE_CASE
)

fun isDeletedText(t: String): Boolean {
    val s = t.lowercase()
    return DELETED_MARKERS.any { s.contains(it) }
}

/**
 * Читает уведомления выбранных мессенджеров на ЭТОМ устройстве, сохраняет их в локальную базу
 * и помечает сообщение удалённым, когда мессенджер заменяет текст на «сообщение удалено».
 */
class NotifListener : NotificationListenerService() {

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        try {
            handle(sbn)
        } catch (_: Throwable) {
        }
    }

    @Suppress("DEPRECATION")
    private fun handle(sbn: StatusBarNotification) {
        val ctx = applicationContext
        if (!Prefs.tracking(ctx)) return
        val pkg = sbn.packageName
        if (pkg == packageName || pkg !in Prefs.watched(ctx)) return

        val n = sbn.notification
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return
        val ex = n.extras ?: return

        val title = ex.getCharSequence(Notification.EXTRA_TITLE)?.toString()?.trim().orEmpty()
        val convo = ex.getCharSequence(Notification.EXTRA_CONVERSATION_TITLE)?.toString()?.trim().orEmpty()
        val chat = convo.ifBlank { title }
        if (chat.isBlank()) return

        val store = Store.get(ctx)
        val items = ArrayList<Triple<String, String, Long>>() // sender, text, time

        val arr = ex.getParcelableArray(Notification.EXTRA_MESSAGES)
        if (arr != null && arr.isNotEmpty()) {
            for (m in Notification.MessagingStyle.Message.getMessagesFromBundleArray(arr)) {
                val text = m.text?.toString()?.trim().orEmpty()
                val sender = (if (Build.VERSION.SDK_INT >= 28) m.senderPerson?.name?.toString() else m.sender?.toString())
                    ?: title
                items += Triple(sender, text, if (m.timestamp > 0) m.timestamp else sbn.postTime)
            }
        } else {
            val text = (ex.getCharSequence(Notification.EXTRA_BIG_TEXT) ?: ex.getCharSequence(Notification.EXTRA_TEXT))
                ?.toString()?.trim().orEmpty()
            items += Triple(title, text, sbn.postTime)
        }

        for ((sender, text, time) in items) {
            if (text.isBlank() || NOISE.containsMatchIn(text)) continue
            if (isDeletedText(text)) {
                val msg = store.markDeleted(pkg, chat, time)
                if (msg != null) alert(chat, msg.text)
            } else {
                store.add(pkg, chat, sender.ifBlank { chat }, text, time)
            }
        }
    }

    private fun alert(chat: String, text: String) {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("deleted", "Удалённые сообщения", NotificationManager.IMPORTANCE_HIGH)
        )
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, "deleted")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Удалено в «$chat»")
            .setContentText(text)
            .setStyle(Notification.BigTextStyle().bigText(text))
            .setContentIntent(pi)
            .setAutoCancel(true)
            .build()
        nm.notify((System.currentTimeMillis() % Int.MAX_VALUE).toInt(), n)
    }
}
