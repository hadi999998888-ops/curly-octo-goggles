package com.extra.neyzislhub

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update

data class KnownApp(val pkg: String, val name: String)

val KNOWN_APPS = listOf(
    KnownApp("com.whatsapp", "WhatsApp"),
    KnownApp("com.whatsapp.w4b", "WhatsApp Business"),
    KnownApp("org.telegram.messenger", "Telegram"),
    KnownApp("org.thunderdog.challegram", "Telegram X"),
    KnownApp("com.viber.voip", "Viber"),
    KnownApp("com.instagram.android", "Instagram"),
    KnownApp("com.facebook.orca", "Messenger"),
    KnownApp("org.thoughtcrime.securesms", "Signal"),
    KnownApp("com.vkontakte.android", "VK"),
    KnownApp("com.discord", "Discord"),
    KnownApp("com.google.android.apps.messaging", "Google Messages"),
)

fun appName(pkg: String): String = KNOWN_APPS.firstOrNull { it.pkg == pkg }?.name ?: pkg

object Prefs {
    /** Ключ доступа. Лежит в коде открытым текстом. */
    const val SECRET_KEY = "FREE_EXtRa302763819"

    val DEFAULT_WATCHED = setOf(
        "com.whatsapp", "com.whatsapp.w4b", "org.telegram.messenger",
        "com.viber.voip", "com.instagram.android", "com.facebook.orca",
    )

    private fun sp(c: Context) = c.applicationContext.getSharedPreferences("hub", Context.MODE_PRIVATE)

    fun keyOk(c: Context) = sp(c).getBoolean("key_ok", false)
    fun setKeyOk(c: Context, v: Boolean) = sp(c).edit().putBoolean("key_ok", v).apply()

    fun tracking(c: Context) = sp(c).getBoolean("tracking", true)
    fun setTracking(c: Context, v: Boolean) = sp(c).edit().putBoolean("tracking", v).apply()

    fun overlayOn(c: Context) = sp(c).getBoolean("overlay_on", false)
    fun setOverlayOn(c: Context, v: Boolean) = sp(c).edit().putBoolean("overlay_on", v).apply()

    fun watched(c: Context): Set<String> = sp(c).getStringSet("watched", null)?.toSet() ?: DEFAULT_WATCHED
    fun setWatched(c: Context, s: Set<String>) = sp(c).edit().putStringSet("watched", s.toSet()).apply()
}

data class Msg(
    val id: Long,
    val pkg: String,
    val chat: String,
    val sender: String,
    val text: String,
    val time: Long,
    val deleted: Boolean,
    val deletedAt: Long,
)

data class ChatItem(
    val pkg: String,
    val chat: String,
    val last: String,
    val time: Long,
    val count: Int,
    val deletedCount: Int,
) {
    val app: String get() = appName(pkg)
}

class Store private constructor(ctx: Context) : SQLiteOpenHelper(ctx.applicationContext, "hub.db", null, 1) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE msgs (id INTEGER PRIMARY KEY AUTOINCREMENT, pkg TEXT NOT NULL, chat TEXT NOT NULL, " +
                "sender TEXT NOT NULL, text TEXT NOT NULL, time INTEGER NOT NULL, " +
                "deleted INTEGER NOT NULL DEFAULT 0, deleted_at INTEGER NOT NULL DEFAULT 0)"
        )
        db.execSQL("CREATE INDEX idx_chat ON msgs(pkg, chat, time)")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}

    private fun Cursor.toMsg() = Msg(
        id = getLong(0), pkg = getString(1), chat = getString(2), sender = getString(3),
        text = getString(4), time = getLong(5), deleted = getInt(6) == 1, deletedAt = getLong(7),
    )

    private val cols = "id, pkg, chat, sender, text, time, deleted, deleted_at"

    fun add(pkg: String, chat: String, sender: String, text: String, time: Long): Boolean {
        val db = writableDatabase
        db.rawQuery(
            "SELECT 1 FROM msgs WHERE pkg=? AND chat=? AND sender=? AND text=? AND time=? LIMIT 1",
            arrayOf(pkg, chat, sender, text, time.toString())
        ).use { if (it.moveToFirst()) return false }
        db.insert("msgs", null, ContentValues().apply {
            put("pkg", pkg); put("chat", chat); put("sender", sender)
            put("text", text); put("time", time)
        })
        changes.update { it + 1 }
        return true
    }

    /**
     * Помечает сообщение удалённым. Сначала ищет точное совпадение по времени сообщения,
     * если нет — берёт последнее неудалённое сообщение этого чата за последние 2 часа (эвристика).
     */
    fun markDeleted(pkg: String, chat: String, time: Long): Msg? {
        val db = writableDatabase
        var target: Long? = null
        db.rawQuery(
            "SELECT id FROM msgs WHERE pkg=? AND chat=? AND time=? AND deleted=0 LIMIT 1",
            arrayOf(pkg, chat, time.toString())
        ).use { if (it.moveToFirst()) target = it.getLong(0) }
        if (target == null) {
            val since = System.currentTimeMillis() - 2 * 3600_000L
            db.rawQuery(
                "SELECT id FROM msgs WHERE pkg=? AND chat=? AND deleted=0 AND time>? ORDER BY time DESC, id DESC LIMIT 1",
                arrayOf(pkg, chat, since.toString())
            ).use { if (it.moveToFirst()) target = it.getLong(0) }
        }
        val id = target ?: return null
        db.execSQL("UPDATE msgs SET deleted=1, deleted_at=? WHERE id=?", arrayOf<Any>(System.currentTimeMillis(), id))
        changes.update { it + 1 }
        db.rawQuery("SELECT $cols FROM msgs WHERE id=?", arrayOf(id.toString())).use {
            return if (it.moveToFirst()) it.toMsg() else null
        }
    }

    fun chats(q: String): List<ChatItem> {
        val sql = "SELECT m.pkg, m.chat, MAX(m.time) AS t, COUNT(*) AS c, SUM(m.deleted) AS d, " +
            "(SELECT x.text FROM msgs x WHERE x.pkg=m.pkg AND x.chat=m.chat ORDER BY x.time DESC, x.id DESC LIMIT 1) AS last " +
            "FROM msgs m " +
            (if (q.isBlank()) "" else "WHERE m.chat LIKE ? OR m.text LIKE ? ") +
            "GROUP BY m.pkg, m.chat ORDER BY t DESC"
        val args = if (q.isBlank()) arrayOf<String>() else arrayOf("%$q%", "%$q%")
        val out = ArrayList<ChatItem>()
        readableDatabase.rawQuery(sql, args).use {
            while (it.moveToNext()) {
                out += ChatItem(it.getString(0), it.getString(1), it.getString(5) ?: "", it.getLong(2), it.getInt(3), it.getInt(4))
            }
        }
        return out
    }

    fun messages(pkg: String, chat: String): List<Msg> {
        val out = ArrayList<Msg>()
        readableDatabase.rawQuery(
            "SELECT $cols FROM msgs WHERE pkg=? AND chat=? ORDER BY time ASC, id ASC", arrayOf(pkg, chat)
        ).use { while (it.moveToNext()) out += it.toMsg() }
        return out
    }

    fun deleted(limit: Int = 500): List<Msg> {
        val out = ArrayList<Msg>()
        readableDatabase.rawQuery(
            "SELECT $cols FROM msgs WHERE deleted=1 ORDER BY deleted_at DESC LIMIT $limit", null
        ).use { while (it.moveToNext()) out += it.toMsg() }
        return out
    }

    fun recent(limit: Int): List<Msg> {
        val out = ArrayList<Msg>()
        readableDatabase.rawQuery(
            "SELECT $cols FROM msgs ORDER BY id DESC LIMIT $limit", null
        ).use { while (it.moveToNext()) out += it.toMsg() }
        return out
    }

    /** total, deleted */
    fun stats(): Pair<Int, Int> {
        readableDatabase.rawQuery("SELECT COUNT(*), COALESCE(SUM(deleted),0) FROM msgs", null).use {
            return if (it.moveToFirst()) it.getInt(0) to it.getInt(1) else 0 to 0
        }
    }

    fun clearAll() {
        writableDatabase.execSQL("DELETE FROM msgs")
        changes.update { it + 1 }
    }

    companion object {
        /** Счётчик изменений — UI перечитывает данные, когда он растёт. */
        val changes = MutableStateFlow(0)

        @Volatile
        private var inst: Store? = null

        fun get(ctx: Context): Store =
            inst ?: synchronized(this) { inst ?: Store(ctx).also { inst = it } }
    }
}
